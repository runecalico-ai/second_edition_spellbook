---
name: Fireball
school: Evocation
class_list:
- Mage
level: 3
components: V,S,M
material_components: Bat guano and sulfur
duration: Instantaneous
area: 20-ft radius burst
saving_throw: Half
tags:
- fire
- area
source: Homebrew/OGL-like summary
edition: AD&D 2e
author: You
license: Homebrew
---

A spark blossoms into a burst of flame affecting a wide area; agile foes can lessen the effect with a save.
