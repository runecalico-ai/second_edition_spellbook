-- 0002_seed_spheres.sql
PRAGMA foreign_keys = ON;
BEGIN;
INSERT OR IGNORE INTO sphere(name) VALUES ('All');
INSERT OR IGNORE INTO sphere(name) VALUES ('Animal');
INSERT OR IGNORE INTO sphere(name) VALUES ('Astral');
INSERT OR IGNORE INTO sphere(name) VALUES ('Charm');
INSERT OR IGNORE INTO sphere(name) VALUES ('Combat');
INSERT OR IGNORE INTO sphere(name) VALUES ('Creation');
INSERT OR IGNORE INTO sphere(name) VALUES ('Divination');
INSERT OR IGNORE INTO sphere(name) VALUES ('Elemental (Air)');
INSERT OR IGNORE INTO sphere(name) VALUES ('Elemental (Earth)');
INSERT OR IGNORE INTO sphere(name) VALUES ('Elemental (Fire)');
INSERT OR IGNORE INTO sphere(name) VALUES ('Elemental (Water)');
INSERT OR IGNORE INTO sphere(name) VALUES ('Guardian');
INSERT OR IGNORE INTO sphere(name) VALUES ('Healing');
INSERT OR IGNORE INTO sphere(name) VALUES ('Law');
INSERT OR IGNORE INTO sphere(name) VALUES ('Chaos');
INSERT OR IGNORE INTO sphere(name) VALUES ('Necromantic');
INSERT OR IGNORE INTO sphere(name) VALUES ('Plant');
INSERT OR IGNORE INTO sphere(name) VALUES ('Protection');
INSERT OR IGNORE INTO sphere(name) VALUES ('Summoning');
INSERT OR IGNORE INTO sphere(name) VALUES ('Sun');
INSERT OR IGNORE INTO sphere(name) VALUES ('Thought');
INSERT OR IGNORE INTO sphere(name) VALUES ('Time');
INSERT OR IGNORE INTO sphere(name) VALUES ('Travelers');
INSERT OR IGNORE INTO sphere(name) VALUES ('War');
INSERT OR IGNORE INTO sphere(name) VALUES ('Weather');
COMMIT;

-- Verification (optional):
-- SELECT name FROM sphere ORDER BY name;