---
name: Magic Missile
school: Evocation
class_list:
- Mage
level: 1
components: V,S
duration: Instantaneous
tags:
- force
- combat
source: Homebrew/OGL-like summary
edition: AD&D 2e
author: You
license: Homebrew
---

Launch one or more bolts of force that unerringly strike targets within range.
