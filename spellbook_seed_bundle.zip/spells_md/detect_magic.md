---
name: Detect Magic
school: Divination
sphere: Divination
class_list:
- Mage
- Cleric
- Druid
level: 1
range: '0'
components: V,S
material_components: ''
casting_time: '1'
duration: 1 turn (concentration)
area: 60-ft cone or per table
saving_throw: None
reversible: false
tags:
- utility
- detection
source: Homebrew/OGL-like summary
edition: AD&D 2e
author: You
license: Homebrew
---

The caster focuses to sense the presence of active or persistent magical auras in the area ahead. 
Strong effects outshine faint ones; identifying schools or specific items usually requires further study.
