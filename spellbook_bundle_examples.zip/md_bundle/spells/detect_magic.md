---
name: Detect Magic
school: Divination
class_list:
- Mage
- Cleric
level: 1
components: V,S
duration: 1 turn (concentration)
area: 60-ft cone
saving_throw: None
tags:
- utility
- detection
source: Homebrew/OGL-like summary
edition: AD&D 2e
author: You
license: Homebrew
---

Sense the presence of magical auras ahead; stronger auras are more obvious.
