---
name: Magic Missile
school: Evocation
class_list:
- Mage
level: 1
components: V,S
duration: Instantaneous
area: One or more creatures
saving_throw: None
tags:
- force
- combat
source: Homebrew/OGL-like summary
edition: AD&D 2e
author: You
license: Homebrew
---

Launch bolts of force that unerringly strike targets within range.
