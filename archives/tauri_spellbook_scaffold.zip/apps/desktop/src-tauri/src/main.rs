#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::sync::Arc;
use r2d2_sqlite::SqliteConnectionManager;
use tauri::Manager;
use serde::{Deserialize, Serialize};

type Pool = r2d2::Pool<SqliteConnectionManager>;

#[derive(Serialize, Deserialize)]
struct Spell {
    id: Option<i64>,
    name: String,
    school: Option<String>,
    level: i64,
    description: Option<String>,
}

#[tauri::command]
async fn ping() -> String {
    "pong".into()
}

#[tauri::command]
async fn search_keyword(state: tauri::State<'_, Arc<Pool>>, query: String) -> Result<Vec<Spell>, String> {
    let conn = state.get().map_err(|e| e.to_string())?.get().map_err(|e| e.to_string())?;
    let mut stmt = conn.prepare("SELECT id, name, school, level, description FROM spell_fts f JOIN spell s ON s.id=f.rowid WHERE f MATCH ? ORDER BY bm25(f) LIMIT 50")
        .map_err(|e| e.to_string())?;
    let rows = stmt.query_map([query], |row| {
        Ok(Spell {
            id: row.get(0)?,
            name: row.get(1)?,
            school: row.get(2)?,
            level: row.get(3)?,
            description: row.get(4)?,
        })
    }).map_err(|e| e.to_string())?;
    let mut out = vec![];
    for r in rows { out.push(r.map_err(|e| e.to_string())?) }
    Ok(out)
}

#[tauri::command]
async fn chat_answer(prompt: String) -> Result<String, String> {
    // TODO: call python sidecar (ctranslate2 + RAG). For now, return a stub.
    Ok(format!("(stub) You asked: {}", prompt))
}

fn init_db() -> Result<Pool, String> {
    let data_dir = tauri::api::path::data_dir().ok_or("no data dir")?.join("SpellbookVault");
    std::fs::create_dir_all(&data_dir).map_err(|e| e.to_string())?;
    let db_path = data_dir.join("spellbook.sqlite3");
    let manager = SqliteConnectionManager::file(&db_path);
    let pool = r2d2::Pool::new(manager).map_err(|e| e.to_string())?;
    {
        let conn = pool.get().map_err(|e| e.to_string())?;
        conn.execute_batch("PRAGMA foreign_keys=ON;").map_err(|e| e.to_string())?;
        // TODO: run migrations from bundled SQL
    }
    Ok(pool)
}

fn main() {
    let pool = init_db().expect("db");
    let shared = Arc::new(pool);

    tauri::Builder::default()
        .manage(shared)
        .invoke_handler(tauri::generate_handler![ping, search_keyword, chat_answer])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
