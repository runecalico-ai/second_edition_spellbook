# Spellbook Bundle Formats — Import/Export Contract

Two interchangeable formats:
1) **JSON Bundle** — single `spellbook.json` file that may include inline spell data (schema: `schemas/spellbook.schema.json`).
2) **Markdown Bundle** — folder with `spellbook.yml` manifest and `spells/*.md` (each spell has YAML front-matter).

## Dedupe/Import
- Canonical key: `(name_normalized, class, level, source)`.
- If a referenced spell is missing locally, create it from inline data (JSON) or MD file.
- On collision, show merge UI and write `artifact` record for provenance.

## Print
- Support layouts: Compact, Stat-Block, List. Include options for A4/Letter, include notes, prepared/known markers.

## Versioning
- `format_version: 1.0.0` (accept any `<2.0.0` by default).
