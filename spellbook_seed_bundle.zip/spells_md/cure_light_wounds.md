---
name: Cure Light Wounds
school: Necromancy
sphere: Healing
class_list:
- Cleric
- Druid
level: 1
range: Touch
components: V,S
material_components: ''
casting_time: '5'
duration: Instantaneous
area: Creature touched
saving_throw: None (harms undead)
reversible: true
tags:
- healing
- support
source: Homebrew/OGL-like summary
edition: AD&D 2e
author: You
license: Homebrew
---

By placing a hand upon the target, the caster mends minor injuries and restores a small amount of vitality. 
If cast on undead, the energy disrupts them instead. This magic cannot restore lost limbs or cure diseases.
