---
name: Magic Missile
school: Evocation
sphere: null
class_list:
- Mage
level: 1
range: 60 yds + 10 yds/level
components: V,S
material_components: ''
casting_time: '1'
duration: Instantaneous
area: One or more creatures
saving_throw: None
reversible: false
tags:
- force
- combat
source: Homebrew/OGL-like summary
edition: AD&D 2e
author: You
license: Homebrew
---

At low levels the caster launches a single bolt of force that unerringly strikes a visible target within range. 
At higher levels, additional bolts appear; each bolt damages a single target of the caster's choosing. 
The spell does not miss, but it cannot harm objects protected from magical force.
